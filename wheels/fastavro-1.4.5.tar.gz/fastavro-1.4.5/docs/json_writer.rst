fastavro.json_write
===================

.. autofunction:: fastavro.json_write.json_writer
