class LimeError(Exception):
    """Raise for errors"""
