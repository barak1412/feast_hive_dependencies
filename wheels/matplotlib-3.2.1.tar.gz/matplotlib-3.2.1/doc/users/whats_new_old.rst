
===================
Previous What's New
===================

.. toctree::
   :glob:
   :maxdepth: 1
   :reversed:

   prev_whats_new/changelog
   prev_whats_new/whats_new_*
