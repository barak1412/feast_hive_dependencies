from automl_infrastructure.experiment.observations.base import SimpleObservation, Observation
from automl_infrastructure.experiment.observations.standard_observations import Std, Avg

